import tkinter as tk
from tkinter import ttk, messagebox
from strategies.backtracking_solver import BacktrackingSolver
from strategies.genetic_solver import GeneticSolver

class NQueensApp:
    def __init__(self, root):
        self.root = root
        self.root.title("N-Queens Solver")

        # گزینه‌ها
        self.n_label = ttk.Label(root, text="Enter N (>=4):")
        self.n_label.pack(pady=5)

        self.n_entry = ttk.Entry(root)
        self.n_entry.pack(pady=5)

        self.algorithm_label = ttk.Label(root, text="Select Algorithm:")
        self.algorithm_label.pack(pady=5)

        self.algorithm_choice = ttk.Combobox(root, values=["Backtracking", "Genetic"])
        self.algorithm_choice.current(0)
        self.algorithm_choice.pack(pady=5)

        self.solve_button = ttk.Button(root, text="Solve", command=self.solve)
        self.solve_button.pack(pady=10)

        self.canvas = tk.Canvas(root, width=400, height=400, bg="white")
        self.canvas.pack(pady=10)

    def solve(self):
        try:
            n = int(self.n_entry.get())
            if n < 4:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Please enter an integer N >= 4")
            return

        algorithm = self.algorithm_choice.get()

        if algorithm == "Backtracking":
            solver = BacktrackingSolver()
            solutions = solver.solve(n)
            solution = solutions[0] if solutions else []
        elif algorithm == "Genetic":
            solver = GeneticSolver()
            solution = solver.solve(n)
        else:
            messagebox.showerror("Error", "Unknown algorithm selected")
            return

        if not solution:
            messagebox.showinfo("Result", "No solution found.")
        else:
            self.draw_board(solution)

    def draw_board(self, solution):
        self.canvas.delete("all")
        n = len(solution)
        size = min(400 // n, 50)

        for row in range(n):
            for col in range(n):
                x1 = col * size
                y1 = row * size
                x2 = x1 + size
                y2 = y1 + size
                fill = "white" if (row + col) % 2 == 0 else "gray"
                self.canvas.create_rectangle(x1, y1, x2, y2, fill=fill)
                if solution[row] == col:
                    self.canvas.create_oval(x1 + 5, y1 + 5, x2 - 5, y2 - 5, fill="red")

if __name__ == "__main__":
    root = tk.Tk()
    app = NQueensApp(root)
    root.mainloop()
