from strategies.solver_strategy import SolverStrategy

class BacktrackingSolver(SolverStrategy):
    def is_safe(self, board, row, col, n):
        for i in range(row):
            if board[i] == col or abs(board[i] - col) == abs(i - row):
                return False
        return True
    
    

    def solve(self, n):
        def backtrack(row):
            if row == n:
                solutions.append(board.copy())
                return
            for col in range(n):
                if self.is_safe(board, row, col, n):
                    board[row] = col
                    backtrack(row + 1)
                    board[row] = -1

        board = [-1] * n
        solutions = []
        backtrack(0)
        return solutions[0] if solutions else []
