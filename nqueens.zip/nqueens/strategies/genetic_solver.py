import random
from strategies.solver_strategy import SolverStrategy

class GeneticSolver(SolverStrategy):
    def fitness(self, board, n):
        conflicts = 0
        for i in range(n):
            for j in range(i + 1, n):
                if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j):
                    conflicts += 1
        return (n * (n - 1)) // 2 - conflicts

    def selection(self, population, fitnesses):
        total_fitness = sum(fitnesses)
        pick = random.uniform(0, total_fitness)
        current = 0
        for board, fit in zip(population, fitnesses):
            current += fit
            if current >= pick:
                return board
        return population[-1]

    def crossover(self, parent1, parent2, n):
        cut1 = random.randint(0, n // 2)
        cut2 = random.randint(cut1, n - 1)
        child = parent1[:cut1] + parent2[cut1:cut2] + parent1[cut2:]
        return child

    def mutate(self, board, n, rate=0.1):
        board = board[:]
        for i in range(n):
            if random.random() < rate:
                board[i] = random.randint(0, n - 1)
        return board

    def solve(self, n, max_generations=1000, population_size=200):
        population = [[random.randint(0, n - 1) for _ in range(n)] for _ in range(population_size)]

        best_fitness = -1
        generations_without_improvement = 0

        for generation in range(max_generations):
            fitnesses = [self.fitness(b, n) for b in population]

            max_fit = max(fitnesses)
            if max_fit == (n * (n - 1)) // 2:
                best_index = fitnesses.index(max_fit)
                return population[best_index]

            if max_fit > best_fitness:
                best_fitness = max_fit
                generations_without_improvement = 0
            else:
                generations_without_improvement += 1

            if generations_without_improvement > 100:
                break

            new_population = []
            for _ in range(population_size):
                parent1 = self.selection(population, fitnesses)
                parent2 = self.selection(population, fitnesses)
                child = self.crossover(parent1, parent2, n)
                child = self.mutate(child, n)
                new_population.append(child)

            population = new_population

        fitnesses = [self.fitness(b, n) for b in population]
        best_index = fitnesses.index(max(fitnesses))
        return population[best_index]
