# main.py

# وارد کردن کلاس‌های استراتژی از پوشه strategies
from strategies.backtracking_solver import BacktrackingSolver
from strategies.genetic_solver import GeneticSolver


def print_board(solution):
    """یک راه‌حل را به‌صورت تصویری در ترمینال چاپ می‌کند"""
    n = len(solution)
    for row_idx in range(n):
        row = ['.'] * n
        col_idx = solution[row_idx]
        if col_idx != -1:
            row[col_idx] = 'Q'
        print(' '.join(row))
    print('-' * (2*n - 1))  # جداکننده


def main():
    print("=== N-Queens Solver ===")
    # گرفتن اندازه صفحه از کاربر
    try:
        n = int(input("Enter the value of N (number of queens): "))
        if n < 4:
            print("N must be at least 4.")
            return
    except ValueError:
        print("Invalid input. Please enter an integer.")
        return

    # گرفتن انتخاب الگوریتم
    print("\nChoose solving algorithm:")
    print("1. Backtracking")
    print("2. Genetic Algorithm")
    choice = input("Enter choice (1 or 2): ")

    # انتخاب استراتژی مناسب
    if choice == '1':
        solver = BacktrackingSolver()
        print("\nSolving using Backtracking..." )
    elif choice == '2':
        solver = GeneticSolver()
        print("\nSolving using Genetic Algorithm..." )
    else:
        print("Invalid choice. Exiting.")
        return

    # اجرای حل‌کننده و نمایش خروجی
    solution = solver.solve(n)
    if not solution:
        print("No solution found.")
    else:
        print(f"\nSolution for {n}-Queens:")
        print_board(solution)


if __name__ == "__main__":
    main()
