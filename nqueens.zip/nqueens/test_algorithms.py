import unittest
from strategies.backtracking_solver import BacktrackingSolver
from strategies.genetic_solver import GeneticSolver

class TestBacktrackingSolver(unittest.TestCase):
    def setUp(self):
        self.solver = BacktrackingSolver()

    def test_backtracking_solution_length(self):
        n = 8
        solutions = self.solver.solve(n)
        self.assertGreater(len(solutions), 0, "Should find at least one solution")
        for solution in solutions:
            self.assertEqual(len(solution), n)

    def test_backtracking_valid_solution(self):
        n = 8
        solution = self.solver.solve(n)[0]
        self.assertTrue(self.is_valid_solution(solution), "Backtracking returned invalid solution")

    def is_valid_solution(self, board):
        n = len(board)
        for i in range(n):
            for j in range(i + 1, n):
                if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j):
                    return False
        return True

class TestGeneticSolver(unittest.TestCase):
    def setUp(self):
        self.solver = GeneticSolver()

    def test_genetic_solution_valid(self):
        n = 8
        solution = self.solver.solve(n)
        self.assertEqual(len(solution), n)
        self.assertTrue(self.is_valid_solution(solution), "Genetic returned invalid solution")

    def is_valid_solution(self, board):
        n = len(board)
        for i in range(n):
            for j in range(i + 1, n):
                if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j):
                    return False
        return True

if __name__ == '__main__':
    unittest.main()
